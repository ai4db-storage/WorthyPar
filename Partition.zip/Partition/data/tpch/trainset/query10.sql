SELECT
     c_custkey, o_orderkey, l_orderkey, l_linenumber, n_nationkey 
FROM
     customer,
     orders,
     lineitem,
     nation
WHERE
     c_custkey = o_custkey
     AND l_orderkey = o_orderkey
     AND o_orderdate >= '1993-10-01'
     AND o_orderdate < cast('1993-10-01' as date) + interval '3' MONTH
     AND l_returnflag = 'R'
     AND c_nationkey = n_nationkey
limit 100;