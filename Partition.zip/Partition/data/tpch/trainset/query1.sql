select
       l_orderkey,
       l_linenumber 
 from
       lineitem
 where
       l_shipdate <= cast('1998-12-01' as date) - interval '90' day;
