SELECT
     l_orderkey, l_linenumber,
     c_custkey,
     o_orderkey 
 FROM  customer, orders, lineitem
WHERE c_mktsegment = 'BUILDING'
  AND c_custkey = o_custkey
  AND l_orderkey = o_orderkey
  AND o_orderdate < '1998-03-15'
  AND l_shipdate > '1998-03-15'
limit 100;
