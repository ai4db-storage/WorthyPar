SELECT
     l_orderkey, l_linenumber, o_orderkey 
FROM
     orders,
     lineitem
WHERE
     o_orderkey = l_orderkey
     AND l_shipmode IN ('MAIL', 'SHIP')
     AND l_commitdate < l_receiptdate
     AND l_shipdate < l_commitdate
     AND l_receiptdate >= '1994-01-01'
     AND l_receiptdate < cast('1994-01-01' as date) + interval '1' YEAR
limit 100;
