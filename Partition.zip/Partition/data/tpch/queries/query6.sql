SELECT
     SUM(l_extendedprice * l_discount) AS revenue
FROM
     lineitem 
WHERE
     l_shipdate >= '1994-01-01'
     AND l_shipdate < cast('1994-01-01' as date) + interval '1' YEAR
     AND l_discount BETWEEN .06 - 0.01 AND .06 + 0.010001
     AND l_quantity < 24
limit 100;
