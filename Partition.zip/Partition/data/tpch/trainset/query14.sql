SELECT
     l_orderkey, l_linenumber, p_partkey 
FROM
     lineitem,
     part
WHERE
     l_partkey = p_partkey
     AND l_shipdate >= '1995-09-01'
     AND l_shipdate < cast('1995-09-01' as date) + interval '1' MONTH
limit 100;
